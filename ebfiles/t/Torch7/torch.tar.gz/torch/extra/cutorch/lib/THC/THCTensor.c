#include "THCGeneral.h"
#include "THCTensor.h"
#include "THCTensorCopy.h"
#include "THAtomic.h"

#include "generic/THCTensor.c"
#include "THCGenerateAllTypes.h"
