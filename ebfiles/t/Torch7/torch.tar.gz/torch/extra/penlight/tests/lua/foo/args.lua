--- test module for demonstrating app.require_here()
local args = {}

function args.answer ()
    return 42
end

return args

