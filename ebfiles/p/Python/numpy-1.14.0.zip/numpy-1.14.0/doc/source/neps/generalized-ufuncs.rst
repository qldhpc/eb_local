.. include:: ../../neps/generalized-ufuncs.rst
