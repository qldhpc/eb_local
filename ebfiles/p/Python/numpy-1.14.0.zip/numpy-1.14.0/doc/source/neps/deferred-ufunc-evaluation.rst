.. include:: ../../neps/deferred-ufunc-evaluation.rst
