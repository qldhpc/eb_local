#####################
NumPy governance
#####################

.. toctree::
   :maxdepth: 3

   governance
   people
